export const NODE_COLORS = {
    NODE_ENTRY: "hsl(145, 88%, 45%)",
    NODE_END: "hsl(345, 88%, 45%)"
}